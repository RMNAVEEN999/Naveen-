const express = require('express')
const app = express()
app.use(express.json())

const format = require('date-fns/format')
const isValid = require('date-fns/isValid')
const toDate = require('date-fns/toDate')

const bcrypt = require('bcrypt')
const jwt = require('jwtwedtoken')
const {open} = require('sqlite')
const splite3 = require('sqlite3')
const path = require('path')
const dbPath = path.join(__dirname, 'todoApplication.db')
let db = null

const crateingDataBaseResponse = async () => {
  try {
    db = await open({
      filename: dbPath,
      dirver: splite3.Database,
    })
    app.listen(3000, () => {
      console.log('SERVER RUNNING http://localhost:3000/')
    })
  } catch (e) {
    console.log(`ERROR:${e.message}`)
  }
}

crateingDataBaseResponse()

const Priority = ['HIGH', 'MEDIUM', 'LOW']
const Status = ['TO DO', 'IN PROGRESS', 'DONE']
const Category = ['WORK', 'HOME', 'LEARNIG']

const checkRequestQuery = async (request, response, next) => {
  const {search_q, category, priority, status, date} = request.query
  const {todoId} = request.params
  if (category !== undefined) {
    const CategoryQuery = Category.includes(category)
    if (CategoryQuery === true) {
      category.request = category
    } else {
      response.status(400)
      response.send('Invalid Todo Category')
      return
    }
  }
  if (priority !== undefined) {
    const PriorityQuery = Priority.includes(priority)
    if (PriorityQuery === true) {
      priority.request = priority
    } else {
      response.status(400)
      response.send('Invalid Todo Priority')
      return
    }
  }
  if (status !== undefined) {
    const StatusQuery = Status.includes(status)
    if (StatusQuery === true) {
      status.request = status
    } else {
      response.status(400)
      response.send('Invalid Todo Status')
      return
    }
  }
  if (date !== undefined) {
    try {
      const myDate = new Date()
      const formatDate = format(new Date(date), 'yyyy-MM-dd')
      console.log(formatDate, 'f')
      const result = toDate(
        new Date(
          `${myDate.getFullYear()}-${myDate.getMonth()}-${myDate.getDate()}`,
        ),
      )
      console.log(result, 'r')
      console.log(new Date())
      const isValidDate = await isValid(result)
      console.log(isValidDate, 'v')
      if (isValidDate === true) {
        date.request = formatDate
      } else {
        response.status(400)
        response.send('Invalid Todo Date')
        return
      }
    } catch (e) {
      response.status(400)
      response.send('Invalid Todo Date')
      return
    }
  }
  request.todoId = todoId
  request.search_q = search_q
  next()
}

const checkResponseBody = async (request, response, next) => {
  const {id, todo, category, priority, status, dueDate} = request.body
  const {todoId} = request.params
  if (category !== undefined) {
    CategoryQuery = Category.includes(category)
    if (CategoryQuery === true) {
      category.request = category
    } else {
      response.status(400)
      response.send('Invalid Todo Category')
      return
    }
  }
  if (priority !== undefined) {
    PriorityQuery = Priority.includes(priority)
    if (PriorityQuery === true) {
      priority.request = priority
    } else {
      response.status(400)
      response.send('Invalid Todo Priority')
      return
    }
  }
  if (status !== undefined) {
    StatusQuery = Status.includes(status)
    if (StatusQuery === true) {
      status.request = status
    } else {
      response.status(400)
      response.send('Invalid Todo Status')
      return
    }
  }

  if (dueDate !== undefined) {
    try {
      const myDate = new Date()
      const formatDate = format(new Date(dueDate), 'yyyy-MM-dd')
      console.log(formatDate)
      const result = toDate(new Date(formatDate))
      const isValidDate = isValid(result)
      console.log(isValidDate)
      console.log(isValidDate)
      if (isValidDate === true) {
        dueDate.request = formatDate
      } else {
        response.status(400)
        response.send('Invalid Todo Due  Date')
        return
      }
    } catch (e) {
      response.status(400)
      response.send('Invalid Todo Due  Date')
      return
    }
  }

  todo.request = todo
  search_q.request = search_q
  next()
}

app.get('/todos/', checkRequestQuery, async (request, response) => {
  const {status = '', search_q = '', priority = '', category = ''} = request
  console.log(status, priority, category, search_q)
  const getTodoQuery = `
    SELECT 
     id,
      todo,
      priority,
      status,
      category,
      due_date AS dueDate
      FROM 
      todo
      WHERE 
      todo LIKE '%${todo}%' AND priority LIKE '%${priority}%' AND status LIKE '%${status}%' AND category LIKE '%${category}%'
      AND dueDate LIKE '%${dueDate}%'
    ;`
  const dbResponse = await db.all(getTodoQuery)
  response.send(dbResponse)
})

app.get('/todos/:todoId/', checkRequestQuery, async (request, response) => {
  const {todoId} = request
  const getQuery = `
    SELECT 
     id,
      todo,
      priority,
      status,
      category,
      due_date AS dueDate
      FROM 
      todo
      WHERE
      id = ${todoId};`
  const TodoResponse = await db.get(getQuery)
  response.send(TodoResponse)
})

app.get('/agenda/', checkRequestQuery, async (request, response) => {
  const {date} = request
  console.log(date, 'a')
  const dateQuery = `
     SELECT 
     id,
      todo,
      priority,
      status,
      category,
      due_date AS dueDate
      FROM 
      todo
      WHERE
      due_date = ${date};

;`
  const DuDateDb = await db.all(dateQuery)
  if (DuDateDb === undefined) {
    response.status(400)
    response.send('Invalid Due Date')
  } else {
    response.send(DuDateDb)
  }
})

app.post('/todos/', checkResponseBody, async (request, response) => {
  const {id, todo, priority, category, status, dueDate} = request
  const addTodoQuery = `
  INSERT INTO todo(id,todo,priority,status,category,duDate)
  VALUES(
    '${id}',
    '${todo}',
    ${category}',
    ${status}',
    ${priority}',
    ${dueDate}'
  );`
  await db.run(addTodoQuery)
  response.send('Todo Successfully Added')
})

app.put('/todos/:todoId/', checkResponseBody, async (request, response) => {
  const {priority, todo, status, category, dueDate} = request
  const {todoId} = request
  let upDateQuery = null
  switch (true) {
    case status !== undefined:
      upDateQuery = `
      UPDATE
      todo
      SET
       status = '${status}'
       WHERE
       id = ${todoId};`
      await db.run(upDateQuery)
      response.send('Status Updated')
      break
    case priority !== undefined:
      upDateQuery = `
      UPDATE
      todo
      SET
       priority = '${priority}'
       WHERE
       id = ${todoId};`
      await db.run(upDateQuery)
      response.send('Priority Update')
      break
    case todo !== undefined:
      upDateQuery = `
      UPDATE
      todo
      SET
       todo = '${todo}'
       WHERE
       id = ${todoId};`
      await db.run(upDateQuery)
      response.send('Todo Update')
      break
    case category !== undefined:
      upDateQuery = `
      UPDATE
      todo
      SET
       category = '${category}'
       WHERE
       id = ${todoId};`
      await db.run(upDateQuery)
      response.send('Category Update')
      break
    case dueDate !== undefined:
      upDateQuery = `
      UPDATE
      todo
      SET
       due_date = '${dueDate}'
       WHERE
       id = ${todoId};`
      await db.run(upDateQuery)
      response.send('Due Date Updated')
      break
  }
})

app.delete('/todos/:todoId/', async (request, response) => {
  const {todoId} = request.params
  const deleteQuery = `
    DELECT  FROM todo WHERE todo = ${todoId};`
  await db.run(deleteQuery)
  response.send('Todo Deleted')
})

module.exports = app
